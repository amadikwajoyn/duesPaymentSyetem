--
-- Database: `pay_dues`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `Dept_payment` varchar(255) NOT NULL,
  `polo` varchar(255) NOT NULL,
  `constitution` varchar(255) NOT NULL,
  `canivar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`Dept_payment`, `polo`, `constitution`, `canivar`) VALUES
('500', '1500', '500', '200');

-- --------------------------------------------------------

--
-- Table structure for table `dues`
--

CREATE TABLE `dues` (
  `id` int(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dues`
--

INSERT INTO `dues` (`id`, `title`, `amount`) VALUES
(1, 'Polo', 1500),
(2, 'Carnivar', 200),
(3, 'Constitution', 500),
(4, 'Project Levy', 3000);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(255) NOT NULL,
  `userid` int(255) NOT NULL,
  `duesid` int(255) NOT NULL,
  `refno` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `session` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `userid`, `duesid`, `refno`, `date`, `session`, `address`, `status`) VALUES
(1, 1, 2, '136076354', '', '2016/2017', 'ND1 WEEKEND', 'Paid'),
(2, 1, 2, '218948974', '', '2016/2017', 'HND2 MORNING', 'Paid'),
(3, 2, 2, '542070617', '', '2016/2017', 'ND1 MORNING', 'Paid'),
(4, 3, 2, '741200561', '', '2016/2017', 'ND1 MORNING', 'Paid'),
(5, 4, 3, '924801330', '', '2016/2017', 'HND1 MORNING', 'Pending'),
(6, 4, 3, '843409118', '', '2016/2017', 'HND1 MORNING', 'Paid'),
(7, 5, 4, '773014221', '', '2016/2017', 'HND2 MORNING', 'Pending'),
(8, 5, 2, '187951049', '', '2016/2017', 'HND2 MORNING', 'Pending'),
(9, 5, 1, '167618103', '', '2016/2017', 'ND1 EVENING', 'Paid'),
(10, 5, 5, '159490966', '', '2016/2017', 'ND1 WEEKEND', 'Pending'),
(11, 5, 3, '895646362', '', '2017', 'HND1 EVENING', 'Paid'),
(12, 5, 4, '503731079', '', '2016/2017', 'HND2 MORNING', 'Paid'),
(13, 5, 4, '520740661', '', '2016/2017', 'HND2 MORNING', 'Paid'),
(14, 5, 3, '709960937', '', '2016/2017', 'HND2 MORNING', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `name` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(80) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `address`, `username`, `password`, `role`) VALUES
(1, 'Amadikwa Joy N.', 'amadkwajoyn@gmail.com', '08165537257', 'Umuerim Nekede', 'joy', '654321joy', 'Admin'),
(3, 'EZEH CYNTHIA IFEOMA', 'ezehcynthiaifeoma@gmail.com', '08161398372', 'clinton lodge', 'cynthia', '654321joy', 'Admin'),
(4, 'Uwadiogwu Michael', 'michaellivingstone@gmail.com', '08165376783', 'HND1 MORNING', '16h/0005/cs', '654321joy', 'Student'),
(5, 'Amadikwa Joy N.', 'amadikwajoyn@gmail.com', '09025362525', 'HND2 MORNING', '16h/0037/cs', '654321joy', 'Student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dues`
--
ALTER TABLE `dues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dues`
--
ALTER TABLE `dues`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
